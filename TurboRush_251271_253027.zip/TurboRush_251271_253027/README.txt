TURBO RUSH GAME 3D 

Jordi Guillén González 253027  jordi.guillen01@estudiant.upf.edu
Nerea Ferrara Ripoll 251271    nerea.ferrara01@estudiant.upf.edu


YouTube link: https://youtu.be/k5FWDsw2R7U

Debug Keys:  

- ESC: return to Menu Stage
- R: restart the game in Play Stage
- P: change to free camera
- 1: Game Over Stage from Menu Stage
- 2: Win Stage from Menu Stage


Develop Part:

- Scene Representation: Jordi Guillén & Nerea Ferrara
- Assets: 
	Circuit created by Jordi Guillén
	Other elements: Internet - Nerea Ferrara
- Render Collisions: Nerea Ferrara
- Physics Simulations through collisions: Jordi Guillén
- Movement of the Player: Jordi Guillén
- AI: Nerea Ferrara
- Sounds: Nerea Ferrara
- 3D Animations: Nerea Ferrara
- GUI and HUD: Jordi Guillén & Nerea Ferrara
